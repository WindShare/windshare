# SCTP RACK verification: 1340f02

Baseline: `6ec762ebc1106ae8c5ce1a69208a98dfcfdddaaf`
Candidate: `1340f02e98f1a7c8f06f865e135ec505a1bce2dc`

`candidate.patch` replays to the candidate's exact exported Git tree. The reproducer
is unchanged from the previous evidence archive. All 52 windows loopback
transfers passed payload verification using go1.27.3 and default protocol timers.

## Results

Five double-loss runs per variant measured lost-retry to next-transmission delay:

| Version | Delay | T3 expirations |
| --- | --- | --- |
| Upstream | 970.2–971.3 ms | 5 |
| 1340f02 | 21.5–30.3 ms | 0 |

The matrix also covers repeated loss, single/no loss, short flights, tail loss,
reordering, late originals, DATA/I-DATA, 50 ms RTT and fragmented messages.
These are recovery measurements, not throughput results. Windows wire timestamps
do not independently establish send ordering in every run; per-run ACK witnesses
and Pion RACK/T3 logs are retained. ACK ambiguity is checked by unit tests.

## Reproduce

Requires Git, Go, Python and PowerShell. Run from the extracted archive:

```powershell
git clone https://github.com/doraemonkeys/sctp ../sctp
git -C ../sctp checkout --detach 1340f02e98f1a7c8f06f865e135ec505a1bce2dc
./build.ps1 -ForkPath ../sctp
python run_matrix.py --output results/new-run
go -C ../sctp test -race -count=1 ./...
```

Use a fresh output directory. The receiver verifies every payload; the wrapper
drops the original transmission and first retry of one TSN, preserving SACKs.

## Version audit

The previous `evidence.zip` tested a different patch. This commit permits retry
delivery evidence without an RTT estimate and judges retry ACK timing after all
RTT samples in the SACK have been processed. With this commit's regression tests,
the previous patch fails four subcases; this commit passes all
30 subcases and the full race suite.

See `verification.json` for commands, revisions and hashes, `summary.json` for
aggregates, `results/` for traces, and `validation/` for test output.
The previous-candidate test log intentionally contains those four failures.
